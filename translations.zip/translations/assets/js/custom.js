$(document).ready(function(){
	//LOAD DATA TABLES
	$(".DataTable").DataTable({
		 "pageLength": 10,
		 "aaSorting": []
	});

	//LOAD DATA TABLE FIXED HEAD
	$('#DataTableFixedHead').DataTable( {
				"pageLength": 25,
		 		"aaSorting": [],
        "scrollY": 400,
        "scrollX": true,
        "columnDefs": [
			    { "width": "100px", "targets": 0 }
			  ]
    } );


	//ON MODAL HIDE
	$(".modal").on("hidden.bs.modal", function () { 
   tinymce.EditorManager.execCommand('mceRemoveEditor' , true, 'txtContent');
   tinymce.EditorManager.execCommand('mceRemoveEditor' , true, 'txtDetailedFeedback');
		tinymce.EditorManager.execCommand('mceRemoveEditor' , true, 'txtMessages');
		 for (var i = tinymce.editors.length - 1 ; i > -1 ; i--) {
            var ed_id = tinymce.editors[i].id;
            tinyMCE.execCommand("mceRemoveControl", true, ed_id);
        }
   // $(".modal").html("");
	}) 


		//ON MODAL HIDE
	$("#modal-feedback-main").on("hidden.bs.modal", function () { 
   	$("#modal-feedback-main").html("");
	}) 


	//LOAD TOASTR
	function loadtoaster(){
		toastr.options = {
		"closeButton": true,
		"timeOut": "5000",
		"positionClass": "toast-top-right"
		}
	}
	
	loadtoaster();

	//jconfim default
		jconfirm.defaults = {
			theme: 'modern',
			draggable: false,
			backgroundDismissAnimation: '',
			content: '',
			 title: '',
		}

	
	//LOAD SELECT2
	$("#slcModel").attr("data-placeholder", "Select model");
  $("#slcJO").attr("data-placeholder", "---");
	$(".select2").select2();	


	//LOAD SELECTIZE
	$('.myselectize').selectize({
    plugins: ['remove_button'],
		maxItems: 2
	});
	//LOAD SELECTIZE NO MAX
	$('.myselectizenomax').selectize({
    plugins: ['remove_button']
	});

	//LOAD TIMEAGO
	 $("abbr.timeago").timeago();

	//LOAD MULTISELECT
	 $('#multiselect').multiselect();

	 //LOAD MULTISELECT WITH SEARCH
	 $('#search').multiselect({
        search: {
            left: '<input autocomplete="off" type="text" name="q" class="form-control" placeholder="Search..." />',
            right: '<input autocomplete="off" type="text" name="q" class="form-control" placeholder="Search..." />',
        },
        fireSearch: function(value) {
            return value.length > 3;
        }
    });

	 //LOAD MCE
	   tinymce.init({
			  selector: "textarea.mce",
			  menubar:false,
			  statusbar: false,
			  debug : false,
			  // toolbar: false,
			  entity_encoding : "named",
			  skin:'light',
			  height : 100,
			  force_br_newlines : true,
			  force_p_newlines : false,
			  forced_root_block : '',
			  plugins : "paste",
			  theme_advanced_buttons3_add : "pastetext,pasteword,selectall",
			  paste_auto_cleanup_on_paste : true,
			  paste_postprocess : function(pl, o) {
			  // Content DOM node containing the DOM structure of the clipboard
			  o.node.innerHTML = o.node.innerHTML;
			  },
			  setup : function(ed)
			    {
			      ed.on('init', function(){
			        this.getDoc().body.style.fontSize = '14px';
			        this.getDoc().body.style.fontFamily = '"Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif';
			      });
			    }
			});

	 //LOAD MCE2
	   tinymce.init({
			  selector: "textarea.mce2",
			  menubar:false,
			  statusbar: false,
			  debug : false,
			  // toolbar: false,
			  entity_encoding : "named",
			  skin:'light',
			  height : 300,
			  force_br_newlines : true,
			  force_p_newlines : false,
			  forced_root_block : '',
			  plugins : "paste",
			  theme_advanced_buttons3_add : "pastetext,pasteword,selectall",
			  paste_auto_cleanup_on_paste : true,
			  paste_postprocess : function(pl, o) {
			  // Content DOM node containing the DOM structure of the clipboard
			  o.node.innerHTML = o.node.innerHTML;
			  },
			  setup : function(ed)
			    {
			      ed.on('init', function(){
			        this.getDoc().body.style.fontSize = '14px';
			        this.getDoc().body.style.fontFamily = '"Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif';
			      });
			    }
			});


	  //LOAD DATEPICKER
    $('.datepicker').daterangepicker({
			    "singleDatePicker": true,
			    "startDate": moment()
			}, function(start, end, label) {
			  console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
			});



    var url_id = getUrlParameter('id');
    console.log(url_id)
    if (url_id) {
    	viewRequest(url_id)
    }




})
// END OF READY FUNCTIONS


$.fn.extend({animateCss:function(animationName) {
  var animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
  $(this).addClass("animated " + animationName).one(animationEnd, function() {
	$(this).removeClass("animated " + animationName);
  });
}});


$(".modal").on('hidden.bs.modal', function () {
   	// $(".modal").html("");
})


$('#filter').keyup(function () {
      var rex = new RegExp($(this).val(), 'i');
      $('.searchable tr').hide();
      $('.searchable tr').filter(function () {
        return rex.test($(this).text());
      }).show();
  });

  var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};


function showLoader(){
		$("#loader").css("display","block");
}

function hideLoader(){
		$("#loader").css("display","none");
}

function loader(id) {
	if (id == 'show') {
			showLoader()
		} else {
			hideLoader()
		}
}



function loadDateRangePicker(){
	$('input[name="duration"]').daterangepicker({
      autoUpdateInput: false,
      showDropdowns: true,
      locale: {
          cancelLabel: 'Clear'
      }
  });

  $('input[name="duration"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  });

  $('input[name="duration"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

}

function loadMCE() {
		   tinymce.init({
			  selector: "textarea.mce",
			  menubar:false,
			  statusbar: false,
			  debug : false,
			  // toolbar: false,
			  entity_encoding : "named",
			  skin:'light',
			  height : 100,
			  force_br_newlines : true,
			  force_p_newlines : false,
			  forced_root_block : '',
			  plugins : "paste",
			  theme_advanced_buttons3_add : "pastetext,pasteword,selectall",
			  paste_auto_cleanup_on_paste : true,
			  paste_postprocess : function(pl, o) {
			  // Content DOM node containing the DOM structure of the clipboard
			  o.node.innerHTML = o.node.innerHTML;
			  },
			  setup : function(ed)
			    {
			      ed.on('init', function(){
			        this.getDoc().body.style.fontSize = '14px';
			        this.getDoc().body.style.fontFamily = '"Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif';
			      });
			    }
			});
}

    function loadSingleDatePicker() {
    	$('.datepicker').daterangepicker({
			    "singleDatePicker": true,
			    "startDate": moment()
			}, function(start, end, label) {
			  console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
			});
    }